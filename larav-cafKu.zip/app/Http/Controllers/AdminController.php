<?php

namespace App\Http\Controllers;
use Auth;
use App\Models\Menu;
use App\Models\Pesanan;
use App\Models\User;
use App\Models\PesananDetail;
use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;

class AdminController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $menu = Menu::all();
        $user = User::all();
        $pesanan_detail = PesananDetail::orderBy('no_meja','desc')->get();
        $pesanan = Pesanan::all();
        
        return view('admin.index', compact( 'user', 'pesanan_detail', 'pesanan','menu'));
    }
    public function user()
    {
     
        $user = User::all();
       
   
        return view('admin.user-data', compact( 'user'));
    }

    public function pesanan_pelanggan()
    {
       
        return view('admin.index', compact('pesanan'));
    }
    public function kirim_pesan($id)
    {
        $penerima = PesananDetail::where('status', 0)->where('id', $id)->get();
        return view('admin.kirim_pesan', compact('penerima'));
    }

    public function kirim_pesan_user(Request $request, $id)
    {
        $pesanan_detail = PesananDetail::where('id', $id)->first();
        $pesanan_detail->status = $request->isi_pesan;
       
        $pesanan_detail->update();
        Toastr::success(' Sukes melakukan pesan', 'Title', ["positionClass" => "toast-top-right"]);

        return redirect('/data-produk');
    }

    public function data_pesanan()
    {
        $menu = Menu::all();
        $user = User::all();
        $pesanan_detail = PesananDetail::orderBy('no_meja','desc')->get();
        $pesanan = Pesanan::all();
        
        return view('admin.pesanan_pelanggan', compact( 'user', 'pesanan_detail', 'pesanan'));
    }

    
}
